
# TransaFacile — Client + Agent MVP

Ce prototype ajoute un Espace Client et un Espace Agent dans la même application.

## Démonstration
- Choix Client / Agent
- Tableau de bord Agent
- Solde Agent et espèces disponibles
- Dépôt client
- Retrait client
- Commissions
- Historique
- État partagé en mémoire entre les écrans

## Important
Les opérations sont simulées localement. Aucune somme réelle n'est transférée.
Pour une version de production, il faudra un backend sécurisé, authentification OTP/PIN,
base de données, journal d'audit, anti-fraude, limites et intégrations officielles
avec les opérateurs/partenaires concernés.

## Lancer
flutter pub get
flutter run

## Générer pour Google Play
flutter build appbundle --release
