
import 'package:flutter/material.dart';

void main() => runApp(const TransaFacileApp());

class Tx {
  final String type, name, network;
  final int amount;
  final bool incoming;
  Tx(this.type, this.name, this.network, this.amount, this.incoming);
}

class DemoState extends ChangeNotifier {
  int clientBalance = 125000;
  int agentBalance = 500000;
  int cash = 300000;
  int commissions = 8500;

  final List<Tx> history = [
    Tx("Dépôt client", "Kouadio Yao", "Orange Money", 20000, true),
    Tx("Retrait client", "Bamba Fatou", "Orange Money", 30000, false),
    Tx("Transfert", "Client TransaFacile", "MTN Mobile Money", 15000, false),
  ];

  void deposit(int amount, String client) {
    if (amount <= 0 || cash < amount) return;
    cash -= amount;
    agentBalance += amount;
    clientBalance += amount;
    commissions += 500;
    history.insert(0, Tx("Dépôt client", client, "TransaFacile", amount, true));
    notifyListeners();
  }

  void withdraw(int amount, String client) {
    if (amount <= 0 || agentBalance < amount || cash + amount > 1000000) return;
    cash += amount;
    agentBalance -= amount;
    clientBalance = (clientBalance - amount).clamp(0, 999999999);
    commissions += 300;
    history.insert(0, Tx("Retrait client", client, "TransaFacile", amount, false));
    notifyListeners();
  }
}

final demo = DemoState();

class TransaFacileApp extends StatelessWidget {
  const TransaFacileApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "TransaFacile",
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF079B48)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F8F6),
      ),
      home: const RoleChooser(),
    );
  }
}

class RoleChooser extends StatelessWidget {
  const RoleChooser({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text("TransaFacile", style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Color(0xFF087A4A))),
            const SizedBox(height: 8),
            const Text("Vos transactions, plus simples, plus rapides."),
            const SizedBox(height: 32),
            _roleButton(context, "👤  Espace Client", const ClientHome()),
            const SizedBox(height: 14),
            _roleButton(context, "🏪  Espace Agent", const AgentHome()),
            const SizedBox(height: 22),
            const Text("Prototype de démonstration — aucune transaction réelle.", textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
        ),
      ),
    );
  }

  Widget _roleButton(BuildContext c, String text, Widget page) => SizedBox(
    width: double.infinity, height: 54,
    child: FilledButton(onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => page)), child: Text(text)),
  );
}

class ClientHome extends StatelessWidget {
  const ClientHome({super.key});
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: demo,
      builder: (_, __) => Scaffold(
        appBar: AppBar(title: const Text("TransaFacile"), actions: [
          IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.swap_horiz))
        ]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          _balanceCard("Solde disponible", demo.clientBalance),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: _action(context, Icons.send, "Envoyer")),
            const SizedBox(width: 10),
            Expanded(child: _action(context, Icons.call_received, "Recevoir")),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _action(context, Icons.storefront, "Payer")),
            const SizedBox(width: 10),
            Expanded(child: _action(context, Icons.phone_android, "Recharger")),
          ]),
          const SizedBox(height: 22),
          const Text("Dernières transactions", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...demo.history.map(_txTile),
        ]),
      ),
    );
  }

  Widget _action(BuildContext c, IconData icon, String label) => FilledButton.tonalIcon(
    onPressed: () => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text("$label — démonstration"))),
    icon: Icon(icon), label: Text(label), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
  );
}

class AgentHome extends StatelessWidget {
  const AgentHome({super.key});
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: demo,
      builder: (_, __) => Scaffold(
        appBar: AppBar(
          title: const Text("Espace Agent"),
          actions: [IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.swap_horiz))],
        ),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [
            Expanded(child: _mini("Solde Agent", demo.agentBalance)),
            const SizedBox(width: 10),
            Expanded(child: _mini("Espèces", demo.cash)),
          ]),
          const SizedBox(height: 10),
          _commissionCard(demo.commissions),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: _bigAction(context, Icons.south_west, "Dépôt", true)),
            const SizedBox(width: 12),
            Expanded(child: _bigAction(context, Icons.north_east, "Retrait", false)),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _secondary(context, Icons.swap_horiz, "Transfert")),
            const SizedBox(width: 12),
            Expanded(child: _secondary(context, Icons.phone_android, "Crédit")),
          ]),
          const SizedBox(height: 24),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text("Transactions récentes", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            TextButton(onPressed: () {}, child: const Text("Voir tout")),
          ]),
          ...demo.history.map(_txTile),
        ]),
      ),
    );
  }

  Widget _bigAction(BuildContext c, IconData icon, String label, bool deposit) => FilledButton.icon(
    onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => AgentOperation(deposit: deposit))),
    icon: Icon(icon), label: Text(label),
    style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(64)),
  );

  Widget _secondary(BuildContext c, IconData icon, String label) => FilledButton.tonalIcon(
    onPressed: () => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text("$label — démonstration"))),
    icon: Icon(icon), label: Text(label), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
  );
}

class AgentOperation extends StatefulWidget {
  final bool deposit;
  const AgentOperation({super.key, required this.deposit});
  @override State<AgentOperation> createState() => _AgentOperationState();
}

class _AgentOperationState extends State<AgentOperation> {
  final phone = TextEditingController(text: "+225 07 07 07 07 07");
  final amount = TextEditingController();
  final name = TextEditingController(text: "Kouadio Yao");

  @override
  Widget build(BuildContext context) {
    final title = widget.deposit ? "Dépôt client" : "Retrait client";
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
          const CircleAvatar(child: Icon(Icons.person)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name.text, style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(phone.text, style: const TextStyle(color: Colors.grey)),
          ]))
        ]))),
        const SizedBox(height: 16),
        TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: "Numéro du client", border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Montant (FCFA)", border: OutlineInputBorder())),
        const SizedBox(height: 22),
        FilledButton(
          onPressed: () {
            final value = int.tryParse(amount.text.replaceAll(" ", "")) ?? 0;
            if (value <= 0) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Entre un montant valide.")));
              return;
            }
            if (widget.deposit) demo.deposit(value, name.text); else demo.withdraw(value, name.text);
            showDialog(context: context, builder: (_) => AlertDialog(
              title: const Text("Transaction confirmée"),
              content: Text("${widget.deposit ? "Dépôt" : "Retrait"} de ${_fmt(value)} FCFA\nClient : ${name.text}"),
              actions: [TextButton(onPressed: () { Navigator.pop(context); Navigator.pop(context); }, child: const Text("OK"))],
            ));
          },
          child: const Text("Vérifier et confirmer"),
        ),
        const SizedBox(height: 14),
        const Text("En production : vérification du client, PIN/OTP, limites, journal d’audit et validation serveur seront obligatoires.",
          style: TextStyle(fontSize: 12, color: Colors.grey)),
      ]),
    );
  }
}

Widget _balanceCard(String title, int value) => Card(
  color: const Color(0xFF087A4A),
  child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(color: Colors.white70)),
    const SizedBox(height: 4),
    Text("${_fmt(value)} FCFA", style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
  ])),
);

Widget _mini(String title, int value) => Card(
  child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(color: Colors.grey, fontSize: 12)),
    const SizedBox(height: 4),
    Text("${_fmt(value)} F", style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
  ])),
);

Widget _commissionCard(int value) => Card(
  color: const Color(0xFFEAF8F0),
  child: ListTile(leading: const CircleAvatar(child: Icon(Icons.monetization_on)), title: const Text("Commissions du jour"),
    subtitle: const Text("Calculées sur les opérations validées"), trailing: Text("${_fmt(value)} F", style: const TextStyle(fontWeight: FontWeight.w900))),
);

Widget _txTile(Tx tx) => Card(
  child: ListTile(
    leading: CircleAvatar(child: Icon(tx.incoming ? Icons.arrow_downward : Icons.arrow_upward)),
    title: Text(tx.type),
    subtitle: Text("${tx.name} • ${tx.network}"),
    trailing: Text("${tx.incoming ? "+" : "-"}${_fmt(tx.amount)} F", style: TextStyle(fontWeight: FontWeight.bold, color: tx.incoming ? Colors.green : Colors.red)),
  ),
);

String _fmt(int n) {
  final s = n.toString();
  final out = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) out.write(' ');
    out.write(s[i]);
  }
  return out.toString();
}
